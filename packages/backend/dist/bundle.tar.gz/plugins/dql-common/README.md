# Dynatrace DQL Plugin Commons

Package name: `@dynatrace/backstage-plugin-dql-common`

Welcome to the DQL commons plugin for Dynatrace!

Thi package provides shared functionality for the [DQL backend](../dql-backend)
and [DQL frontend](../dql) plugins.
